/* This file is auto generated, version 53 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#53 SMP Sun Aug 28 14:25:39 PDT 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1~16.04.2) "
