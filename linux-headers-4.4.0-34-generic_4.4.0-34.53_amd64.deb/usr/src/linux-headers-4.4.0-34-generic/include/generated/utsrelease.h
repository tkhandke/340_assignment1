#define UTS_RELEASE "4.4.0-34-generic"
#define UTS_UBUNTU_RELEASE_ABI 34
